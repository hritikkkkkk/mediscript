import { motion } from 'motion/react';
import { 
  Scale, 
  AlertTriangle, 
  Phone, 
  MessageCircle, 
  Edit3, 
  Heart, 
  Thermometer, 
  Activity,
  Plus,
  MoreVertical,
  FileText,
  Bell,
  Calendar,
  CheckCircle
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { Screen, AuthUser } from './Shared';
import { db } from '../lib/firebase';
import { collection, query, where, getDocs, orderBy, limit, doc, updateDoc, addDoc, serverTimestamp } from 'firebase/firestore';

export default function PatientProfile({ user, setScreen }: { user: AuthUser, setScreen: (s: Screen) => void }) {
  const [patient, setPatient] = useState<any>(null);
  const [prescriptions, setPrescriptions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const doctorId = user.email;

  // Demographics Editing State
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    dob: '',
    phone: '',
    address: ''
  });

  // Reminder State
  const [reminders, setReminders] = useState<any[]>([]);
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [newReminder, setNewReminder] = useState({
    date: '',
    message: ''
  });

  const fetchReminders = async (patientId: string) => {
    try {
      const q = query(
        collection(db, 'reminders'),
        where('patient_id', '==', patientId),
        orderBy('date', 'desc')
      );
      const snap = await getDocs(q);
      setReminders(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (e) {
      console.error("Error fetching reminders:", e);
    }
  };

  const handleAddReminder = async () => {
    if (!patient || !newReminder.date) return;
    try {
      await addDoc(collection(db, 'reminders'), {
        doctor_id: doctorId,
        patient_id: patient.id,
        patient_name: patient.name,
        date: newReminder.date,
        message: newReminder.message,
        status: 'pending',
        created_at: serverTimestamp()
      });
      setShowReminderForm(false);
      setNewReminder({ date: '', message: '' });
      fetchReminders(patient.id);
    } catch (e) {
      console.error("Error adding reminder:", e);
    }
  };

  const handleUpdateDemographics = async () => {
    if (!patient) return;
    try {
      const patientRef = doc(db, 'patients', patient.id);
      await updateDoc(patientRef, editData);
      setPatient({ ...patient, ...editData });
      setIsEditing(false);
    } catch (error) {
      console.error("Error updating demographics:", error);
    }
  };

  const startEditing = () => {
    setEditData({
      dob: patient.dob || '',
      phone: patient.phone || '',
      address: patient.address || ''
    });
    setIsEditing(true);
  };

  useEffect(() => {
    const fetchData = async () => {
      if (!doctorId) return;
      try {
        // Fetch most recent patient for this doctor
        const patientQ = query(
          collection(db, 'patients'),
          where('doctor_id', '==', doctorId),
          orderBy('last_visited', 'desc'),
          limit(1)
        );
        const patientSnap = await getDocs(patientQ);
        
        if (!patientSnap.empty) {
          const patientData = { id: patientSnap.docs[0].id, ...patientSnap.docs[0].data() };
          setPatient(patientData);
          fetchReminders(patientData.id);

          // Fetch prescriptions for this patient
          const rxQ = query(
            collection(db, 'prescriptions'),
            where('patient_id', '==', patientData.id),
            orderBy('created_at', 'desc')
          );
          const rxSnap = await getDocs(rxQ);
          const rxList = await Promise.all(rxSnap.docs.map(async (doc) => {
            const rxData = { id: doc.id, ...doc.data() };
            // Fetch items for this rx
            const itemsQ = query(collection(db, 'prescription_items'), where('prescription_id', '==', rxData.id));
            const itemsSnap = await getDocs(itemsQ);
            return {
              ...rxData,
              items: itemsSnap.docs.map(iDoc => iDoc.data())
            };
          }));
          setPrescriptions(rxList);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [doctorId]);

  if (loading) return <div className="h-full flex items-center justify-center font-bold">Loading Clinical Profile...</div>;
  return (
    <div className="h-full bg-white flex flex-col font-sans">
      {/* Allergy Warning Banner */}
      {patient.allergies && patient.allergies.length > 0 && (
        <div className="bg-red-600 text-white px-6 py-3 flex items-center justify-between font-bold uppercase tracking-widest text-[10px] animate-pulse">
          <div className="flex items-center gap-3">
            <AlertTriangle size={16} />
            CRITICAL ALLERGY ALERT: {patient.allergies.join(', ')}
          </div>
          <div className="flex items-center gap-2">
            <Activity size={14} />
            HIGH RISK
          </div>
        </div>
      )}

      {/* Header / Demographics Bar */}
      <div className="bg-zinc-50 border-b border-zinc-200 p-8 flex flex-col md:flex-row gap-8 items-start">
        <div className="w-24 h-24 rounded-[32px] overflow-hidden shadow-sm border border-zinc-200 flex items-center justify-center bg-white">
           <img 
            src={`https://ui-avatars.com/api/?name=${encodeURIComponent(patient.name)}&background=random`} 
            alt="Patient" 
            className="w-full h-full object-cover"
          />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-4 mb-4">
            <h2 className="text-4xl font-serif font-medium tracking-tight text-zinc-950">{patient.name}</h2>
            <span className="px-3 py-1 bg-zinc-200 text-zinc-600 rounded-full text-[10px] font-bold uppercase tracking-widest">{patient.id.slice(-6)}</span>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            <div className="space-y-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Biological Info</p>
              <p className="text-sm font-bold text-zinc-950">{patient.age}Y • {patient.gender}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Vitals Overview</p>
              <p className="text-sm font-bold text-zinc-950">{patient.weight || '72'}kg • {patient.blood_group || 'O+'}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Phone</p>
              <p className="text-sm font-bold text-zinc-950">{patient.phone}</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Last Encounter</p>
              <p className="text-sm font-bold text-zinc-950 italic">{patient.last_visited ? new Date(patient.last_visited.seconds * 1000).toLocaleDateString() : 'Today'}</p>
            </div>
            <div className="flex items-end">
              <button 
                onClick={() => setScreen('NEW_PRESCRIPTION')}
                className="bg-black text-white px-5 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest flex items-center gap-2 hover:bg-zinc-800 transition-all shadow-lg"
              >
                <Plus size={14} /> New Rx
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="p-8 max-w-7xl mx-auto w-full grid grid-cols-1 md:grid-cols-12 gap-8 overflow-y-auto">
        {/* Left: Stats & Reminders */}
        <div className="md:col-span-4 space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white border border-zinc-100 p-5 rounded-2xl flex flex-col justify-between h-28 shadow-sm">
              <div className="flex items-center gap-2 text-zinc-400">
                <Heart size={16} />
                <span className="text-[8px] font-bold uppercase tracking-widest">Blood Pressure</span>
              </div>
              <p className="font-mono text-xl font-bold">130/85</p>
            </div>
            <div className="bg-white border border-zinc-100 p-5 rounded-2xl flex flex-col justify-between h-28 shadow-sm">
              <div className="flex items-center gap-2 text-zinc-400">
                <Thermometer size={16} />
                <span className="text-[8px] font-bold uppercase tracking-widest">Temperature</span>
              </div>
              <p className="font-mono text-xl font-bold">98.6°F</p>
            </div>
            <div className="bg-zinc-950 text-white p-5 rounded-2xl col-span-2 shadow-xl flex flex-col justify-between h-28">
               <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-zinc-400">
                  <Activity size={16} />
                  <span className="text-[8px] font-bold uppercase tracking-widest">Blood Glucose</span>
                </div>
                <span className="text-[8px] font-bold uppercase tracking-widest text-zinc-500">Fasting</span>
              </div>
              <p className="font-mono text-2xl font-bold text-red-500">110 <span className="text-sm font-medium text-zinc-500">mg/dL</span></p>
            </div>
          </div>

          <div className="bg-zinc-50 rounded-2xl p-6 border border-zinc-200">
             <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <Bell size={16} className="text-red-600" />
                <h3 className="text-[10px] font-bold uppercase tracking-[0.2em] italic">Active Reminders</h3>
              </div>
              <button 
                onClick={() => setShowReminderForm(!showReminderForm)}
                className="w-8 h-8 bg-black text-white rounded-xl flex items-center justify-center hover:bg-zinc-800"
              >
                <Plus size={14} />
              </button>
            </div>

            {showReminderForm && (
              <div className="mb-4 bg-white p-4 rounded-xl shadow-sm border border-zinc-100 space-y-3">
                <input 
                  type="date"
                  value={newReminder.date}
                  onChange={(e) => setNewReminder({ ...newReminder, date: e.target.value })}
                  className="w-full bg-zinc-50 border-none rounded-lg px-3 py-2 text-sm" 
                />
                <input 
                  type="text"
                  placeholder="Task description..."
                  value={newReminder.message}
                  onChange={(e) => setNewReminder({ ...newReminder, message: e.target.value })}
                  className="w-full bg-zinc-50 border-none rounded-lg px-3 py-2 text-sm" 
                />
                <button 
                  onClick={handleAddReminder}
                  className="w-full py-2 bg-black text-white rounded-lg text-[10px] font-bold uppercase tracking-widest"
                >
                  Confirm Reminder
                </button>
              </div>
            )}

            <div className="space-y-3">
              {reminders.map((r) => (
                <div key={r.id} className="flex items-start gap-4 p-3 bg-white border border-zinc-100 rounded-xl shadow-xs">
                  <div className="w-1.5 h-1.5 bg-red-600 rounded-full mt-1.5"></div>
                  <div>
                    <p className="text-xs font-bold">{r.message}</p>
                    <p className="text-[10px] font-medium text-zinc-400 uppercase tracking-widest">{r.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: History */}
        <div className="md:col-span-8 space-y-6">
          <h3 className="font-serif text-3xl font-bold">Encounters Registry</h3>
          <div className="space-y-4 pb-12">
            {prescriptions.map((rx, idx) => (
              <motion.div 
                key={rx.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white border border-zinc-100 p-8 rounded-3xl group shadow-sm hover:shadow-md transition-all border-l-4 border-l-red-600"
              >
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">{new Date(rx.created_at?.seconds * 1000).toLocaleDateString()}</p>
                    <h4 className="font-serif text-2xl font-bold group-hover:text-red-600 transition-colors">{rx.diagnosis}</h4>
                  </div>
                  <CheckCircle size={20} className="text-zinc-200 group-hover:text-emerald-500 transition-colors" />
                </div>

                <div className="flex flex-wrap gap-2">
                  {rx.items?.map((item: any, i: number) => (
                    <span key={i} className="inline-flex items-center gap-2 px-3 py-1.5 bg-zinc-50 text-zinc-950 text-xs font-bold rounded-lg border border-zinc-100 uppercase tracking-tighter">
                      {item.name} {item.strength} • <span className="text-red-600">{item.frequency}</span>
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
